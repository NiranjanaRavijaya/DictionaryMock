package com.automation.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;
import java.util.concurrent.TimeUnit;


public class dictionaryutils 
{
	public static String getWord() {
		return word;
	}
	public static void setWord(String word) {
		dictionaryutils.word = word;
	}
	//The necessary word to be searched is given here
	 private static String word= "working";
		public static String isEnglishWord(String word) throws InterruptedException
		{
	//add the corresponding chrome driver path in local
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();	
			driver.get("https://www.dictionary.com/");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		    driver.findElement(By.id("searchbar_input")).sendKeys(word);
		    driver.findElement(By.id("search-submit")).click();
	//checks if It is an English word or not
		    if ( driver.getPageSource().contains("No results found for"))
		    {
		    System.out.println("It is not an english word  ");
		    }
    //If it is an English word then it finds the possible types of anagrams in the given word
		    else 
		    {
		         System.out.println("It is an english word  ");
		         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		         driver.get("https://www.thewordfinder.com/anagram-solver/"); 
		         WebElement search =driver.findElement(By.id("search"));
		         search.sendKeys(word);
		         search.sendKeys(Keys.ENTER);
		         List<WebElement> elements = driver.findElements(By.xpath("/html/body/div[1]/div[1]/div[2]/div[1]/div[3]/div/p"));
		         System.out.println("Number of meaningful anagram words:" +elements.size());
     //Displays the different anagrams with count without repeating them
		         for (int i=0; i<elements.size();i++){
		           System.out.println("The anagram words are " + elements.get(i).getText());
		      }
	         driver.close();
		}return word;
		}
	}
