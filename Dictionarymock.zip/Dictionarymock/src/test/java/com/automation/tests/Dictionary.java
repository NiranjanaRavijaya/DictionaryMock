package com.automation.tests;
import com.automation.utils.dictionaryutils;

public class Dictionary extends dictionaryutils{
	static String s1=dictionaryutils.getWord() ;
		public static void main(String []args ) throws InterruptedException {
			
		dictionaryutils.isEnglishWord(s1);
			
			
		}


	}

